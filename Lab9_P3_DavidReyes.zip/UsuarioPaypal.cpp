#include "UsuarioPaypal.h"

UsuarioPaypal::UsuarioPaypal(string, string, string,double,double,string)
{
	this->Nombre;
	this->Id;
	this->Pass;
	this->cantidad;
	this->deposito;
	this->Historial;
}
UsuarioPaypal::UsuarioPaypal(){

}
double UsuarioPaypal::getdeposito()
{
	return deposito;
}
string UsuarioPaypal::getnombre()
{
	return Nombre;
}
string UsuarioPaypal::getid()
{
	return Id;
}

string UsuarioPaypal::getpass()
{
	return Pass;
}

string UsuarioPaypal::gethistorial()
{
	return Historial;
}

double UsuarioPaypal::getcantidad()
{
	return cantidad;
}

void UsuarioPaypal::setnombre(string nombre)
{
	 this->Nombre=nombre;
}

void UsuarioPaypal::setid(string id)
{
	this->Id = id;
}

void UsuarioPaypal::setpass(string pass)
{
	this->Pass = pass;
}

void UsuarioPaypal::sethistorial(string historial)
{
	this->Historial = historial;
}

void UsuarioPaypal::setdeposito(double deposito)
{
	this->deposito = deposito;
}

void UsuarioPaypal::setcantidad(double cantidad)
{
	this->cantidad = cantidad;
}

UsuarioPaypal::~UsuarioPaypal() {
	//delete ;
}

