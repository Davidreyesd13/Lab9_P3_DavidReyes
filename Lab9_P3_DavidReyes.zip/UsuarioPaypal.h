#pragma once
#include <string>
using namespace std;
class UsuarioPaypal
{
	string Nombre, Id,Pass,Historial;
	double deposito, cantidad;
public:
	UsuarioPaypal(string, string, string, double,double,string);
	UsuarioPaypal();
	double getdeposito();
	string getnombre();
	string getid();
	string getpass();
	string gethistorial();
	double getcantidad();
	void setnombre(string);
	void setid(string);
	void setpass(string);
	void sethistorial(string);
	void setdeposito(double);
	void setcantidad(double);
	~UsuarioPaypal();
};
