#pragma once
#include "UsuarioPaypal.h"
class Wallet{
	string usuario,pass;
	double doge,etherium,Waltercoin;
public:
	Wallet();
	Wallet(string,string,double,double,double);
	string getusuario();
	string getpass();
	double getdoge();
	double getetherium();
	double getWaltercoin();
	void setusuario(string);
	void setpass(string);
	void setdoge(double);
	void setetherium(double);
	void setWaltercoin(double);
};

