#include "Paypal.h"

Paypal::Paypal(vector<UsuarioPaypal*> base)
{
	this->base = base;
}
Paypal::Paypal() {

}