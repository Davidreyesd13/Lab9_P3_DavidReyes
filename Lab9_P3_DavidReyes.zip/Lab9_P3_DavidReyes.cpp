#include <iostream>
#include "UsuarioPaypal.h"
#include "Wallet.h"
#include "UsuarioPaypal.h"
using namespace std;
void menu() {
	string user, pass;
	int op = 1,opcion_paypal,opcion_wallet;
	double deposito,retiro;
	while (op!=6) {
		cout << "1.Crear cuenta de paypal\n2.Crear Wallet\n3.Cargar informacion\n4.Acceder a Paypal";
		cout<<	"\n5.Acceder a Wallet\n6. Salir";
		cin >> op;
		switch (op) {
		case 1:
			
			break;
		case 2:
			
			break;
		case 3:
			while () {
				cout << "User or Password incorrect";
				cout << "User: ";
				cin >> user;
				cout << "Password: ";
				cin >> pass;
			}
			while (opcion_paypal!=5) {
				cout << "1.Ver estado de cuenta\n2.Hacer deposito a mi propia cuenta\n3.Hacer retiro de mi cuenta\n4.Ver historial de cuenta";
				cin >> opcion_paypal;
				switch (opcion_paypal) {
				case 1:

					break;
				case 2:
					cout << "Ingrese la cantidad de deposito: ";
					cin >> deposito;

					break;
				case 3:
					cout << "Ingrese la cantidad que desea retirar: ";
					cin >> retiro;
					break;
				case 4:

					break;
				case 5:

					break;
				}
			}
			break;
		case 4:
			while () {
				cout << "User or Password incorrect";
				cout << "User: ";
				cin >> user;
				cout << "Password: ";
				cin >> pass;
			}
			while (opcion_wallet!=5) {
				cout << "1.Ver estado de cuenta\n2.Comprar cryptos\n3.Vender cryptos\n5.Salir";
				cin >> opcion_wallet;
				switch () {
				case 1:
					
					break;
				case 2:
					
					break;
				case 3:
					
					break;
				case 5:

					break;
				default:
					cout << "Opcion no valida";
					break;
				}
			}
			break;
		case 5:

			break;
		case 6:
			cout << "Buen Dia";
			break;
		default:
			cout << "Opcion no valida";
			break;
		}
	}
}
int main()
{
	menu();
}