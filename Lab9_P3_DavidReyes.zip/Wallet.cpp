#include "Wallet.h"

Wallet::Wallet() {

}

Wallet::Wallet(string, string, double, double, double)
{
	this->usuario;
	this->pass;
	this->doge;
	this->etherium;
	this->Waltercoin;
}

string Wallet::getusuario()
{
	return string();
}

string Wallet::getpass()
{
	return string();
}

double Wallet::getdoge()
{
	return 0.0;
}

double Wallet::getetherium()
{
	return 0.0;
}

double Wallet::getWaltercoin()
{
	return 0.0;
}

void Wallet::setusuario(string)
{
}

void Wallet::setpass(string)
{
	
}

void Wallet::setdoge(double doge)
{
	this->doge=doge;
}

void Wallet::setetherium(double etc)
{
	this->etherium = etc;
}

void Wallet::setWaltercoin(double wc)
{
	this->Waltercoin = wc;
}
